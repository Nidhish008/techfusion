from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq

chat = ChatGroq(temperature=0, groq_api_key="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", model_name="mixtral-8x7b-32768")

system = "You are a helpful assistant."
human = "{text}"
prompt = ChatPromptTemplate.from_messages([("system", system), ("human", human)])

chain = prompt | chat
a = chain.invoke({"text": "what is computer"})
print(a.content)